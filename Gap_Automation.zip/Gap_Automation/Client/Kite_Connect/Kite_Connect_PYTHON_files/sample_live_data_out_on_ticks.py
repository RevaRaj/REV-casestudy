import logging
from kiteconnect import KiteTicker,KiteConnect
import datetime
from all_file_path import *
import pandas as pd


logging.basicConfig(level=logging.DEBUG)
api_key="mufcn0llb3sbzw5p"
access_token="N2UqWOv2s74e6RWyx6R7snArqmQqP0RQ"

'''kws = KiteTicker("mufcn0llb3sbzw5p", "bT5g5TxXE9rYoESX2swYZtdt20EO7Jpa")
kite = KiteConnect(api_key="mufcn0llb3sbzw5p",access_token="bT5g5TxXE9rYoESX2swYZtdt20EO7Jpa")'''

order_time=datetime.time(hour=13,minute=34,second=00)
current_time=datetime.datetime.now().time().replace(microsecond=0)
print(order_time)
print(current_time)
count=0
df_token=pd.read_csv(token_path)
symbol_ltp=dict()

def login(api_k,acc_tok):
    global kws,kite
    print("from login")
    kite=KiteConnect(api_k,acc_tok)
    kite.set_access_token(acc_tok)
    kws=KiteTicker(api_k,acc_tok)

login(api_key,access_token)

def on_ticks(ws, ticks):
#    logging.debug("Ticks: {}".format(ticks))
    print("From Main on ticks")

def on_connect(ws, response):
    ws.subscribe([738561, 5633])
    ws.set_mode(ws.MODE_FULL, [738561])

def on_close(ws, code, reason):
    ws.stop()

kws.on_ticks = on_ticks
kws.on_connect = on_connect
kws.on_close = on_close
kws.connect(threaded=True)

while True:
   #Perform required data operation using tick data

#   if current_time>=order_time:
    def on_ticks(ws, ticks):
           feed_data(ticks)
           print("i'm from while loop on ticks feed_data is called now")


    def feed_data(ticks):
           print("from feed data function")
           for tick in ticks:
               print(tick['instrument_token'])

    kws.on_ticks = on_ticks



   # Assign callback


