from kiteconnect import KiteTicker,KiteConnect
import datetime
from all_file_path import *
import pandas as pd
import logging
from com.dakshata.autotrader.api.AutoTrader import AutoTrader
from gap import Gap
from api_access_keys import *

api_key,access_token,auto_key=keys()
autotrader = AutoTrader.create_instance(auto_key, AutoTrader.SERVER_URL)


INSTRUMENT=[738561]

order_time=datetime.time(hour=13,minute=12,second=00)

'''api_key=open(api_key_path,"r").read()
access_token=open(access_token_path,"r").read()'''

class KiteManager:

    def __init__(self):
        self.kws = KiteTicker(api_key, access_token)
        self.kite = KiteConnect(api_key=api_key, access_token=access_token)
        self.kite.set_access_token(access_token)
        self.current_time = datetime.datetime.now().time().replace(microsecond=0)
        self.count=0
        self.results=[]
        self.results1=[]
        self.kws.on_ticks = self.on_ticks
        self.kws.on_connect = self.on_connect
        self.kws.on_close = self.on_close
        self.kws.connect(threaded=True)
        self.start_time=datetime.datetime.now().replace(microsecond=0)
        print("start time :",self.start_time)
        self.diff=0
        self.end_time=datetime.datetime.now().replace(microsecond=0)

    def on_connect(self,ws, response):
        print("in on_connect")
        ws.subscribe(INSTRUMENT)
        ws.set_mode(ws.MODE_FULL, INSTRUMENT)


    def on_ticks(self,ws, ticks):
        print("in on_ticks")
        ws.subscribe(INSTRUMENT)
        ws.set_mode(ws.MODE_FULL, INSTRUMENT)
#        print(ticks[0]['last_price'])

    def on_close(self,ws, code, reason):
        ws.stop()

    def process(self):

        while self.count<=5 :

            def on_ticks(ws, ticks):
               feed_data(ticks)
               print("while on ticks")


            '''def on_close(ws, code, reason):
               ws.stop()'''

            def feed_data(ticks):
                for tick in ticks:
                    self.end_time = datetime.datetime.now().replace(microsecond=0)
                    print("End time : ", self.end_time)
                    self.diff = (self.end_time - self.start_time).total_seconds()
                    print(self.diff)
                    self.results.append(tick['last_price'])
                    print("***********************************")


                if self.diff == 60:
                        print(self.results)
                        temp = dict()
                        temp['open'] = self.results[0]
                        temp['high'] = max(self.results)
                        temp['low'] = min(self.results)
                        temp['close'] = self.results[len(self.results) - 1]
                        self.results1.append(temp)
                        df = pd.DataFrame(self.results1)
                        print(df)
                        print("____________________________________________________________________________")
                        self.count += 1
                        self.start_time=self.end_time


            self.kws.on_ticks = on_ticks


obj=KiteManager()
obj.process()
