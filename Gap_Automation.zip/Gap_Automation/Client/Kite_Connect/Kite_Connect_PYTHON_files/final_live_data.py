
# import logging ---> if this is enabled then will get debug message while placing order
from kiteconnect import KiteTicker,KiteConnect
import datetime
from all_file_path import *
import pandas as pd
from com.dakshata.autotrader.api.AutoTrader import AutoTrader
from twisted.internet import reactor


#logging.basicConfig(level=logging.DEBUG)
'''api_key=open(api_key_path,"r").read()
access_token=open(access_token_path,"r").read()'''
api_key="mufcn0llb3sbzw5p"
access_token="s4uwGIszvThGB81lPw260XRHdC4vFRbH"
print(api_key, access_token)
autotrader = AutoTrader.create_instance('9a5f1026-4f77-4ca9-9bb4-45c54205505c', AutoTrader.SERVER_URL)

'''kws = KiteTicker("mufcn0llb3sbzw5p", "bT5g5TxXE9rYoESX2swYZtdt20EO7Jpa")
kite = KiteConnect(api_key="mufcn0llb3sbzw5p",access_token="bT5g5TxXE9rYoESX2swYZtdt20EO7Jpa")
'''
order_time=datetime.time(hour=10,minute=3,second=0)
exit_time=datetime.time(hour=15,minute=30,second=0)
current_time=datetime.datetime.now().time().replace(microsecond=0)




count=0
df_token=pd.read_csv(gap_token_path)
symbol_ltp=dict()

def login(api_k,acc_tok):
    global kws,kite,ws
    print("from login")
    kite=KiteConnect(api_k,acc_tok)
    kite.set_access_token(acc_tok)
    kws=KiteTicker(api_k,acc_tok)

login(api_key,access_token)

def on_ticks(ws, ticks):
#    logging.debug("Ticks: {}".format(ticks))
#    logging.basicConfig(level=logging.DEBUG)
    print("From Main on ticks")


def on_connect(ws, response):
    ws.subscribe([738561, 5633])
    ws.set_mode(ws.MODE_FULL, [738561])

def on_close(ws, code, reason):
    ws.stop()
def on_error():
    pass

kws.on_ticks = on_ticks
kws.on_connect = on_connect
kws.on_close = on_close
kws.connect(threaded=True)


def place_order(symbol_ltp,):
    global count
    #    global df_token


    for key in symbol_ltp:
        ltp = symbol_ltp[key]

        for i, row in df_token.iterrows():

            if int(key) == row['instrument_token']:
                symbol = row['tradingsymbol']
                #                print("in place order if loop",symbol, key, ltp )

                sl_price = round((ltp + ltp * (1 / 100)), 1)
                #                execution_time = datetime.datetime.now().time()
                response = autotrader.place_cover_order("Revathi", 'NSE', symbol, 'SELL', 'MARKET', 1, ltp,sl_price)

                print("order placed for ", symbol, ltp, datetime.datetime.now().time(),)
    count += 1



while count==0 :
   #Perform required data operation using tick data
   def on_ticks(ws, ticks):
       feed_data(ticks)


   def on_close(ws, code, reason):
       ws.stop()

   def feed_data(ticks):

       current_time = datetime.datetime.now().time().replace(microsecond=0)
       for tick in ticks:
           symbol_ltp[tick['instrument_token']] = tick['last_price']


       if current_time >= order_time and count == 0:
            place_order(symbol_ltp)

       print("Feed data")

   kws.on_ticks = on_ticks




