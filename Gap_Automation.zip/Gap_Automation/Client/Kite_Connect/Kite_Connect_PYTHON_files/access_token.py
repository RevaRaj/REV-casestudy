from kiteconnect import KiteConnect
from all_file_path import *
# access token changes everyday or on session disconnect
# run this program everyday after 8.30 to get new access token for the day


api_key = "mufcn0llb3sbzw5p"
api_secret_key = "xb3aisnez756es4a5x5o56hl22j6gzw4"
kite = KiteConnect(api_key=api_key)

print(kite.login_url())

''' login into this url to get the request token
https://kite.trade/connect/login?api_key=mufcn0llb3sbzw5p&v=3'''

# request token changes everytime
request_token = input("Enter Request token here :")#Rm1V10YmFWuzOJttnItT7yCcwa3u2E7F"
dict1=kite.generate_session(request_token, api_secret_key)
acc_token='"'+str(dict1['access_token'])+'"'
print(acc_token)
open(access_token_path, "w").write(f"{acc_token}")



