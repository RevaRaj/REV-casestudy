from com.dakshata.autotrader.api.AutoTrader import AutoTrader
import datetime

auto_key="9a5f1026-4f77-4ca9-9bb4-45c54205505c"
autotrader = AutoTrader.create_instance(auto_key, AutoTrader.SERVER_URL)

class Orders:
    def __init__(self):
        self.count=0

    def place_MIS_order(self, df_sym_token):
        for i, row in df_sym_token.iterrows():

            response = autotrader.place_regular_order(row['acc_name'], 'NSE', row['symbol'], 'SELL', 'MARKET',
                                                      'INTRADAY',
                                                      row['share_count'], row['ltp'], 0.0)
            #                print(" MIS order placed for ", row['acc_name'], row['symbol'], row['ltp'],
            #                      datetime.datetime.now().time())
#            self.mod_sl[row['acc_name']] = response.result
            '''response1 = autotrader.read_platform_orders(row['acc_name'])
            if response1.success():
                for o in response1.result:
                    if (o.id == response.result) and (o.status == "REJECTED"):
                        pass
'''
        self.count += 1
        return self.count

    def place_CO_order(self, df_sym_token):

        for i, row in df_sym_token.iterrows():

                response = autotrader.place_cover_order(row['acc_name'], 'NSE', row['symbol'], 'SELL', 'MARKET',
                                                        row['share_count'], row['ltp'], row['sl_price'])
                print(" CO order placed for ", row['acc_name'], row['symbol'], row['ltp'],
                      datetime.datetime.now().time())
#                self.mod_sl[row['acc_name']] = response.result
                response1 = autotrader.read_platform_orders(row['acc_name'])
                if response1.success():
                    for o in response1.result:
                        if (o.id == response.result) and (o.status == "REJECTED"):
                            pass

        self.count += 1
        return self.count
