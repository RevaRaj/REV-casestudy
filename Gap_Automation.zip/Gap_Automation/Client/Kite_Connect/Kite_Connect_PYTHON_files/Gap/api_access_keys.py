from all_file_path import *


def keys():
    api_key = "mufcn0llb3sbzw5p"
    acc_token = "N2UqWOv2s74e6RWyx6R7snArqmQqP0RQ"
    auto_key="9a5f1026-4f77-4ca9-9bb4-45c54205505c"

    return api_key,acc_token,auto_key


