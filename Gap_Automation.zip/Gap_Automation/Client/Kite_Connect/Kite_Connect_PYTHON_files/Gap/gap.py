import pandas as pd
from data import download_data
import time
from all_file_path import *

df_token=pd.read_csv(gap_token_path)

class Gap:

    def __init__(self):
        self.results = []
        self.STOCKS_LIST=[]
        self.list2 = []
        self.results1=[]

    def day_open(self):
        self.df_ph = pd.read_csv(prev_high_path)

        self.df_open = download_data()
        self.df_open.to_csv(open_path,index=False)
        self.df_open=pd.read_csv(open_path)
        print(f"Check day open at location :{open_path}")



    def gap_stocks_list(self):

        self.day_open()

        for i, row in self.df_ph.iterrows():
            count = 0
            for i1, row1 in self.df_open.iterrows():

                if (row1['symbol'] == row['symbol']) and (count == 0):
                    if row1['open'] > row['prev_high']:
                        temp = dict()
                        temp['symbol'] = row1['symbol']
                        temp['prev_high'] = row['prev_high']
                        temp['open'] = row1['open']
                        self.results.append(temp)
                        count = 1

        df_gap = pd.DataFrame(self.results)
        print(df_gap)
        if not df_gap.empty:
            df_gap['gap_percent'] = round((100 * (df_gap['open'] - df_gap['prev_high']) / df_gap['prev_high']), 3)
            df_gap = df_gap.sort_values(['gap_percent'], ascending=False)
            df_gap.to_csv(gap_percent_path, index=False)
            print("************************\nGap Stocks with percent\n************************\n", df_gap)
            df = df_gap['symbol'].iloc[0:2]  # taking 1st 2 gapstocks


            symbol_list = [i[1] for i in df.iteritems()]
            print(symbol_list)

            for l in symbol_list:
                for i,row in df_token.iterrows():
                    if l==row['tradingsymbol']:
                        temp=dict()
                        temp['symbol']=row['tradingsymbol']
                        temp['token']=row['instrument_token']
                        self.results1.append(temp)
                        self.list2.append(row['instrument_token'])
            df_tokensym=pd.DataFrame(self.results1)
            return self.list2,df_tokensym,symbol_list
        else:
            print(" No GAP TODAY ")
            exit()


'''obj=Gap()
l=obj.gap_stocks_list()
print(l)'''









