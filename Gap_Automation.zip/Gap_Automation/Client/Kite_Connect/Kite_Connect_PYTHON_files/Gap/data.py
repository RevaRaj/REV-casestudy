import requests
import datetime
import json
import pandas as pd
import time



def download_data():


    DATA_URL = 'https://www.nseindia.com/api/equity-stockIndices?index=SECURITIES%20IN%20F%26O'

    mapping = dict(
        symbol='symbol',
        open='open',
        dayHigh='prev_high',
        dayLow='low',
        lastPrice='close',
        totalTradedVolume='volume',
        #    timestamp='datetime',
    )
    system_time=datetime.datetime.now().time()
#    print("System_time:" ,system_time)
    session = requests.Session()

    session.headers[
        'User-Agent'] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.146 Safari/537.36"
    session.get('https://www.nseindia.com/')
    session.get('https://www.nseindia.com/market-data/live-equity-market?symbol=NIFTY%2050')
    #            session.get('https://www.nseindia.com/api/equity-stockIndices?index=SECURITIES%20IN%20F%26O')
    response = session.get(DATA_URL)
    system_time = datetime.datetime.now().time()
#    print(f"**************************************************************\n{response} time : {system_time}")
    response = json.loads(response.text)
    #            print(response)
    df = pd.DataFrame(data=response['data'])
    df = df.rename(columns=mapping)
    df = df[mapping.values()]
    df['datetime'] = response['timestamp']
    df['datetime'] = pd.to_datetime(df['datetime'])
    df = df.drop(['volume'], axis=1)
    df = df.sort_values(['symbol'])
    return df








