import pandas as pd
from data import download_data
import time
from all_file_path import *


def prev_high():
    df_ph = download_data()
    df_ph.to_csv(prev_high_path, index=False)
    print(f"Check prev high at location : {prev_high_path}")



prev_high()
