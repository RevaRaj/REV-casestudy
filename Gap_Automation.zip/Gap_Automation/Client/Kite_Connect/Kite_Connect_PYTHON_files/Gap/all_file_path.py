'''***************************************
 all file paths  for gap auto orders.py'''

error_file_path = "F:\\Project\\Auto_bat_files\\Execution.txt"
risk_path = "F:\\Project\\Auto_bat_files\\risk.xlsx"
risk_path_reva = "F:\\Project\\Auto_bat_files\\risk_reva.xlsx"
prev_high_path="F:\\Project\\Auto_bat_files\\prev_high.csv"
open_path="F:\\Project\\Auto_bat_files\\day_open.csv"
gap_percent_path='F:\\Project\\Auto_bat_files\\gap_percent.csv'
expiry_path="F:\\Project\\Auto_bat_files\\expiry.csv"
lot_size_path="F:\\Project\\Auto_bat_files\\lot_size.csv"
token_path="F:\\Kite_Connect\\instruments_token.csv"
gap_token_path="F:\\Kite_Connect\\gap_token.csv"
api_key_path="F:\\Project\\Auto_bat_files\\api_key.txt"
access_token_path="F:\\Project\\Auto_bat_files\\acc_token.txt"


