from kiteconnect import KiteTicker,KiteConnect
import datetime
from all_file_path import *
import pandas as pd
import logging
from com.dakshata.autotrader.api.AutoTrader import AutoTrader
from gap import Gap
from api_access_keys import *
from orders import *

api_key,access_token,auto_key=keys()

autotrader = AutoTrader.create_instance(auto_key, AutoTrader.SERVER_URL)


df_risk = pd.read_excel(risk_path,sheet_name="Sheet1",engine='openpyxl')
instrument,df_token,symbol_list=Gap().gap_stocks_list()
print(df_risk)
print(df_token)

order_time=datetime.time(hour=12,minute=54,second=00)

'''print(instrument)
print(df_token)'''

'''api_key=open(api_key_path,"r").read()
access_token=open(access_token_path,"r").read()'''

class KiteManager:

    def __init__(self):
        self.kws = KiteTicker(api_key, access_token)
        self.kite = KiteConnect(api_key=api_key, access_token=access_token)
        self.kite.set_access_token(access_token)
        self.current_time = datetime.datetime.now().time().replace(microsecond=0)
        self.count=0
        self.df_sym_token=pd.DataFrame()
#        self.results=[]
        self.kws.on_ticks = self.on_ticks
        self.kws.on_connect = self.on_connect
        self.kws.on_close = self.on_close
        self.kws.connect(threaded=True)
        self.no_of_shares=0
        self.no_of_stocks=len(instrument)
        self.mod_sl=dict()
        self.order_id=[]
        self.temp = {}


    def on_connect(self,ws, response):
        print("in on_connect")
        ws.subscribe(instrument)
        ws.set_mode(ws.MODE_FULL, instrument)


    def on_ticks(self,ws, ticks):
        print("in on_ticks")
        ws.subscribe(instrument)
        ws.set_mode(ws.MODE_FULL, instrument)
        print(ticks[0]['last_price'])

    def on_close(self,ws, code, reason):
        ws.stop()

    def process(self):

        while self.count==0 :

            def on_ticks(ws, ticks):
               feed_data(ticks)
               print("while on ticks")


            def feed_data(ticks):

                results = []
                for i1, row1 in df_risk.iterrows():
                    self.temp[row1['name']] = {}
                    for i, row in df_token.iterrows():
                        self.temp[row1['name']][row['symbol']] = []
                        for tick in ticks:

                           if tick['instrument_token'] == row['token'] :

                               self.temp[row1['name']][row['symbol']].append(tick['instrument_token'])
                               self.temp[row1['name']][row['symbol']].append( tick['last_price'])
                               self.temp[row1['name']][row['symbol']].append(row1['stop_loss'])
                               if self.no_of_stocks==2:
                                   self.temp[row1['name']][row['symbol']].append(int(round((row1['pos_value']/tick['last_price']),0))) # pos value/entry)
                               elif self.no_of_stocks==1:
                                   self.temp[row1['name']][row['symbol']].append(int(round(((row1['pos_value'] * 2) / tick['last_price']), 0)))  # pos value/entry
                               self.temp[row1['name']][row['symbol']].append(row1['order_type'])


                print(self.temp)


                current_time = datetime.datetime.now().time().replace(microsecond=0)
                if current_time >= order_time and self.count == 0:
                    response_rev = autotrader.place_regular_order("Revathi", 'NSE', symbol_list[0], 'SELL','MARKET','INTRADAY',self.temp['Revathi'][symbol_list[0]][3], 0.0, 0.0)

                    response1_rev=autotrader.place_regular_order("Revathi", 'NSE', symbol_list[1], 'SELL','MARKET','INTRADAY',self.temp['Revathi'][symbol_list[1]][3], 0.0, 0.0)

                    response_sol = autotrader.place_regular_order("Solai", 'NSE', symbol_list[0], 'SELL','MARKET', 'INTRADAY',self.temp['Revathi'][symbol_list[0]][3], 0.0, 0.0)

                    response1_sol = autotrader.place_regular_order("Solai", 'NSE', symbol_list[1], 'SELL','MARKET', 'INTRADAY',self.temp['Revathi'][symbol_list[1]][3], 0.0, 0.0)

                    

                    self.count += 1
            self.kws.on_ticks = on_ticks


obj=KiteManager()
obj.process()