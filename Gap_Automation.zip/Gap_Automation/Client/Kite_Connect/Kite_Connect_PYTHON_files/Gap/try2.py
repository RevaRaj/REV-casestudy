'''dict1={"revathi":
    {"name1":"reva","age":33},
       "raj":     {"name":"raj","age":39},
       "prani":     {"name":"prani","age":8}
}


print(dict1['revathi']['name1'])'''

dict1={}
dict1['Revathi']= {}

dict1['Raj']={}
dict1['Revathi']['TCS']=[]

dict1['Revathi']['TCS'].append(1318)

print(dict1['Revathi']['TCS'][0])