import time
import logging
from kiteconnect import KiteTicker

from kiteconnect import KiteConnect


instrument="738561"

from_date='2021-03-17'
to_date="2021-03-17"
interval="5minute"
kite=KiteConnect(api_key="mufcn0llb3sbzw5p")
kite.set_access_token("pRGgenWlUQLGCNbQUakeOrnDeWOdCJxF")

def get_historical_data():
    return kite.historical_data(instrument,from_date,to_date,interval)


df=get_historical_data()
print()
