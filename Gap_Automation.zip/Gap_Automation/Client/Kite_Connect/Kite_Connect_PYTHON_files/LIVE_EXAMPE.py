import time
import logging

from kiteconnect import KiteTicker,KiteConnect
from auto_order import Place_Order
#from access_token import access_token
import datetime
from com.dakshata.autotrader.api.AutoTrader import AutoTrader
kite = KiteConnect(api_key="mufcn0llb3sbzw5p",access_token="bT5g5TxXE9rYoESX2swYZtdt20EO7Jpa")

order_time=datetime.time(hour=12,minute=32,second=00)

logging.basicConfig(level=logging.DEBUG)
#access_token=access_token()

class KiteManager:

    def __init__(self):
        self.kws = KiteTicker("mufcn0llb3sbzw5p", "bT5g5TxXE9rYoESX2swYZtdt20EO7Jpa")
        self.current_time = datetime.datetime.now().time().replace(microsecond=0)
        self.count=0

    def on_connect(self,ws, response):
        print("in on_connect")

        # Manipulate list accordingly
        ws.subscribe(self.instrument)
        # Set RELIANCE to tick in `full` mode.
        ws.set_mode(ws.MODE_FULL, self.instrument)


    def on_ticks(self,ws, ticks):
        print("in on_ticks")
#        logging.debug("Ticks: {}".format(ticks))
        ws.subscribe(self.instrument)

        # Set RELIANCE to tick in `full` mode.
        ws.set_mode(ws.MODE_FULL, self.instrument)


        return ticks


    def on_close(self,ws, code, reason):
        # On connection close stop the main loop
        # Reconnection will not happen after executing `ws.stop()`
        ws.stop()

    def run(self,instrument):
        print("in run")
        self.instrument = instrument
        self.kws.on_ticks = self.on_ticks
        self.kws.on_connect = self.on_connect
        self.kws.on_close = self.on_close
        self.kws.connect()

    #        self.kws.on_close = self.on_close

'''obj=KiteManager()
obj.run(instrument)'''