import json
import pandas as pd

json_data = open('D:\\Truuth\\scores_verifications\\verifications.json')

data = json.load(json_data)
maindict = []


import pandas as pd

c = pd.to_datetime(int('1331856001000'), utc=True, unit='ms')


for item in data:
    datatodf = {}
    keys = list(item.keys())
    
    if 'tenantAlias' in keys:
        datatodf['tenantName'] = item['tenantAlias']

    if 'createdAt' in keys:
            datatodf['createdAt'] = pd.to_datetime(item['createdAt']['$date']['$numberLong'],utc=True, unit='ms')

    if 'verificationId' in keys:
        datatodf['verificationId'] = item['verificationId']
    if 'results' in keys:
        datatodf['authenticityScore'] = item['results']['processingOutput']['documents'][0]['authenticityVerificationResult']['authenticityScore']
        datatodf['faceMatchScore'] = item['results']['processingOutput']['documents'][0]['faceMatchVerificationResult']['details']['similarity']
        datatodf['livenessScore'] = item['results']['liveness']['score']
   
    maindict.append(datatodf)

df = pd.DataFrame(maindict)
df.to_csv("numobile-verifications12sept.csv",index=False)