from pymongo import MongoClient
import pandas as pd
from datetime import date, timedelta
import os

from sqlalchemy import null

collectionName = "verifications"
#   Add the tenants here if needed

listOfTenants = [ "acdemo1", "admin", "advanceai", "afg", "afg-consumer",
                    "caf","client", "config","console","frostyinc",
                    "fruuth","give", "gym","iag","iip",
                    "jiafinance","laddr","lgf","local","lociiparser",
                    "macquarie","manual-verification","movigo",
                    "newtnt","paytron","petsure","platform",
                    "propper","raineandhome","releaseau","right2drive",
                    "selfonboarding","socar","supporttenant","truuthdemo1",
                    "truuthproduct","truuthsupport","tup","v2testing",
                    "numobile", "afg", "hays"]

#listOfTenants = ["hays","numobile"]
class Verifications:
    def __init__(self,connection):
        self.connectionString = connection
        self.final_scores = []
        self.get_database()
        

    def get_database(self):
        
        # Provide the mongodb atlas url to connect python to mongodb
        CONNECTION_STRING = self.connectionString

        # Create a connection using MongoClient and get all database names
        client = MongoClient(CONNECTION_STRING)
        databases = client.list_database_names()
        directory = self.create_directory(str(date.today()))
        #directory = self.create_directory(str(date.today() - timedelta(days = 1)))
        scores = []
        
        for db in databases:            
            
                       
            if db in listOfTenants :
                collections = client[db].list_collection_names()
                for collec in collections:
                    if collectionName == collec:
                        records = client[db][collectionName]
                        print("tenant : ",db)
                        self.get_reports(records)
        df = pd.DataFrame(self.final_scores)
        if not df.empty:
            print(df,"\n*****************************************\n")
            df.to_csv(f"{directory}-all_client-{date.today()}_report.csv",index=False)
            

    def create_directory(self,folder):
        current_directory = os.getcwd()
        final_directory = os.path.join(current_directory, folder)
        if not os.path.exists(final_directory):
            os.makedirs(final_directory)

        return final_directory

    def get_reports(self,records):
        
        
        for record in records.find():
                datatodf = {}
                keys = list(record.keys())                
                results = record.get('results',None)
                documents = record.get('documents',None)
                
                
                if  record['status'] == 'DONE':
                    print(record['tenantAlias'])
                    print(record['verificationId'])
                    
                    if 'tenantAlias' in keys:
                        datatodf['tenantId'] = record['tenantAlias']

                    if 'verificationId' in keys:
                        datatodf['verificationId'] = record['verificationId']
                                                     
                    if 'results' in keys and  results is not None :
                        if 'processingOutput' in record['results'].keys():
                            auth_result = results.get('processingOutput').get('documents')
                            for i in range(0,len(record['results']['processingOutput']['documents'])):
                                doc_type = 'document type'+str(i)
                                auth_score = 'authscore'+str(i)
                                doc_name = 'Display Name'+str(i)
                                if 'authenticityVerificationResult' in record['results']['processingOutput']['documents'][i].keys():
    
                                    result1 = auth_result[i].get('authenticityVerificationResult')
                                    if result1 is not None:
                                        auth_keys = result1.keys()
                                        
                                        datatodf[doc_type] = record['results']['processingOutput']['documents'][i]['documentType']
                                        if 'score' in auth_keys:
                                            datatodf[auth_score] = record['results']['processingOutput']['documents'][i]['authenticityVerificationResult']['score']
                                        elif   'authenticityScore' in auth_keys:
                                            datatodf[auth_score] = record['results']['processingOutput']['documents'][i]['authenticityVerificationResult']['authenticityScore']
                                        if 'documentDisplayName' in record['results']['processingOutput']['documents'][i].keys():
                                            datatodf[doc_name] = record['results']['processingOutput']['documents'][i]['documentDisplayName']
                                
                                
                                
                                
                                
                                elif  'manualAuthenticityVerificationResult' in record['results']['processingOutput']['documents'][i].keys():
                                    result1 = auth_result[i].get('manualAuthenticityVerificationResult')
                                    if result1 is not None:
                                        auth_keys = result1.keys()
                                        
                                        datatodf[doc_type] = record['results']['processingOutput']['documents'][i]['documentType']
                                        if 'score' in auth_keys:
                                            datatodf[auth_score] = record['results']['processingOutput']['documents'][i]['manualAuthenticityVerificationResult']['score']
                                        elif   'authenticityScore' in auth_keys:
                                            datatodf[auth_score] = record['results']['processingOutput']['documents'][i]['manualAuthenticityVerificationResult']['authenticityScore']
                                        if 'documentDisplayName' in record['results']['processingOutput']['documents'][i].keys():
                                            datatodf[doc_name] = record['results']['processingOutput']['documents'][i]['documentDisplayName']
                                
                               
                    print("*************************************")   
                    print(datatodf)    
                    self.final_scores.append(datatodf)
        



if __name__ == "__main__":    
    
    #connectionString = "mongodb+srv://revathi:ncFp5BgErH4C7M5q@cluster0-gpn3z.mongodb.net/admin?authSource=admin&replicaSet=Cluster0-shard-0&readPreference=primary&authMechanism=SCRAM-SHA-1&appname=MongoDB%20Compass&ssl=true"
    connectionString = "mongodb+srv://revathi:oa1sktMzBlzLvR0V@truuth-cluster-au.nfws6.mongodb.net/admin?authSource=admin&replicaSet=atlas-2e1zer-shard-0&w=majority&readPreference=primary&authMechanism=SCRAM-SHA-1&appname=MongoDB%20Compass&retryWrites=true&ssl=true"
    Verifications(connectionString)