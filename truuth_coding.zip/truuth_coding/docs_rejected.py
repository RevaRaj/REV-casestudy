from pymongo import MongoClient
import pandas as pd
from datetime import date, timedelta
import os

from sqlalchemy import null

collectionName = "verifications"
#   Add the tenants here if needed

listOfTenants = [ "hays","numobile"]


class Verifications:
    def __init__(self,connection):
        self.connectionString = connection
        self.get_database()

    def get_database(self):
        
        # Provide the mongodb atlas url to connect python to mongodb
        CONNECTION_STRING = self.connectionString

        # Create a connection using MongoClient and get all database names
        client = MongoClient(CONNECTION_STRING)
        databases = client.list_database_names()
        directory = self.create_directory(str(date.today()))
        #directory = self.create_directory(str(date.today() - timedelta(days = 1)))

        for db in databases:            
            
                       
            if db in listOfTenants :
                collections = client[db].list_collection_names()
                for collec in collections:
                    if collectionName == collec:
                        records = client[db][collectionName]
                        print("tenant : ",db)
                        scores = self.get_reports(records)
                        df = pd.DataFrame(scores)
                        if not df.empty:
                            print(df,"\n*****************************************\n")
                            df.to_csv(f"{directory}/{db}-fail-{date.today()}_report.csv",index=False)
            

    def create_directory(self,folder):
        current_directory = os.getcwd()
        final_directory = os.path.join(current_directory, folder)
        if not os.path.exists(final_directory):
            os.makedirs(final_directory)

        return final_directory

    def get_reports(self,records):
        finalScores = []

        for record in records.find():
                datatodf = {}
                keys = list(record.keys())                
                results = record.get('results',None)
                documents = record.get('documents',None)
                
                
                if  record['status'] == 'DONE' :
                    if 'results' in keys and  results is not None and record['results']['verificationStatus']=="FAIL" :
                        print(record['verificationId'])
                        
                        if 'tenantAlias' in keys:
                            datatodf['tenantId'] = record['tenantAlias']

                        if 'verificationId' in keys:
                            datatodf['verificationId'] = record['verificationId']
                    
                        
                        if 'createdAt' in keys:
                                datatodf['creation date/time'] = record['createdAt']   
                        if 'updatedAt' in keys:
                            datatodf['updatedAt'] = record['updatedAt'] 
                            
                        if 'completedAt' in keys:
                            datatodf['completion date/time'] = record['completedAt']  
                        
                                                            
                        
                        datatodf['verification result'] = record['results']['verificationStatus']
                        datatodf['failure_reason'] = record['results']['failureReasons'][0]
                        datatodf['Data Edit'] = record['features']['reviewEdit']['required']
                        datatodf['liveness_check_status'] = record['livenessCheck']['status']
                        datatodf['liveness_score'] = record['livenessCheck']['score']
                        
                        print("*************************************")   
                        
                        finalScores.append(datatodf)
        return finalScores



if __name__ == "__main__":    
    
    #connectionString = "mongodb+srv://revathi:ncFp5BgErH4C7M5q@cluster0-gpn3z.mongodb.net/admin?authSource=admin&replicaSet=Cluster0-shard-0&readPreference=primary&authMechanism=SCRAM-SHA-1&appname=MongoDB%20Compass&ssl=true"
    connectionString = "mongodb+srv://revathi:oa1sktMzBlzLvR0V@truuth-cluster-au.nfws6.mongodb.net/admin?authSource=admin&replicaSet=atlas-2e1zer-shard-0&w=majority&readPreference=primary&authMechanism=SCRAM-SHA-1&appname=MongoDB%20Compass&retryWrites=true&ssl=true"
    Verifications(connectionString)