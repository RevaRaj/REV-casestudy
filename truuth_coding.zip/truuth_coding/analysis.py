from pymongo import MongoClient
import pandas as pd
from datetime import date, timedelta,datetime
import os
from pytz import timezone

from sqlalchemy import null

collectionName = "verifications"
#   Add the tenants here if needed

listOfTenants = [ "numobile"]


class Verifications:
    def __init__(self,connection):
        self.connectionString = connection
        self.get_database()

    def get_database(self):
        
        # Provide the mongodb atlas url to connect python to mongodb
        CONNECTION_STRING = self.connectionString

        # Create a connection using MongoClient and get all database names
        client = MongoClient(CONNECTION_STRING)
        databases = client.list_database_names()
        directory = self.create_directory(str(date.today())+"-prod")
        #directory = self.create_directory(str(date.today() - timedelta(days = 1)))

        for db in databases:            
            
                       
            if db in listOfTenants :
                collections = client[db].list_collection_names()
                for collec in collections:
                    if collectionName == collec:
                        records = client[db][collectionName]
                        print("tenant : ",db)
                        scores = self.get_reports(records)
                        df = pd.DataFrame(scores)
                        #df['creation date/time'] = pd.to_datetime(df['initial invitation date/time'],utc=True).dt.tz_convert('Australia/Sydney')
                        #print(df[['verificationId', 'creation date/time']])
                        if not df.empty:
                            #print(df,"\n*****************************************\n")
                            df.loc[df['completion date/time'].isnull(), 'Completion flag'] = 0 
                            df.loc[df['completion date/time'].notnull(), 'Completion flag'] = 1 
                            #df['Completion flag'] = df['completion date/time'].apply(lambda x: 0 if x ==" " else 1)
                            df1 = df[["tenantId", "verificationId","status","customerRef",
                                     "initial invitation date/time", "updatedAt", "completion date/time",
                                     "verification result","primary document type","Invitation date/time(AEST)",
                                     "Invitation date(AEST)","completion date(AEST)","completion time(AEST)",
                                     "updated time(AEST)","Completion flag"]].copy()
                            df2 = df[["tenantId","verificationId",	"status",
                                      	"customerRef",	"Invitation date/time(AEST)",	"verification result",
                                        "primary document type",	"Doc Display Name",	"Doc-Authenticity-Check-status",
                                        "Doc-Authenticity-Check-reason",	"Doc-Authenticity-Check-score",
                                        "Expiry-Check-status",	"Expiry-Check-reason",	"Data-Edit-Check-status",
                                        "Data-Edit-Check-reason",	"Face-Match-Check-status",	"Face-Match-Check-reason",
                                    	"Face-Match-Check-score",	"Liveness-status",	"Liveness-score",	
                                        "authoritative-Check-status",	"authoritative-Check-reason"]].copy()
                            df2 = df[df["verification result"]=="FAIL"]
                            
                            #df.to_csv(f"{directory}/{db}-sample-{date.today()}-report.csv",index=False)
                            summary = {'Date':[date.today()],
                                      'Total Verifications sent': [df.shape[0]],
                                      'Total Verifications completed' : [len(df[df["Completion flag"]==1])],
                                      'Total not started' : [len(df[df["status"]=='NEW'])],
                                      'Total in progress' : [len(df[df["status"]=='IN_PROGRESS'])],
                                      'Pass' : [len(df[df['verification result'] == 'PASS'])],
                                      'Fail' : [len(df[df['verification result'] == 'FAIL'])]

                                      }
                            df3 = pd.DataFrame(summary)
                            df3['Completion rate'] = df3['Total Verifications completed']/df3['Total Verifications sent']
                            df3['Pass(percent)'] = df3['Pass']/df3['Total Verifications completed']
                            print(df3)

                            with pd.ExcelWriter('output1.xlsx') as writer:  
                                df3.to_excel(writer, sheet_name='Daily Summary',index=False)
                                df1.to_excel(writer, sheet_name='Verification Details Data',index=False)
                                df2.to_excel(writer, sheet_name='Rejection Analysis',index=False)
            

    def create_directory(self,folder):
        current_directory = os.getcwd()
        final_directory = os.path.join(current_directory, folder)
        if not os.path.exists(final_directory):
            os.makedirs(final_directory)

        return final_directory

    def get_reports(self,records):
        finalScores = []

        for record in records.find():
                datatodf = {}
                keys = list(record.keys())                
                results = record.get('results',None)
                documents = record.get('documents',None)
                
                
                if  'createdAt' in keys and record['createdAt'] >= (datetime.today() - timedelta(days = 1)) and  record['status'] != 'DELETE':
                    print(record['verificationId'])
                    
                    
                    if 'tenantAlias' in keys:
                        datatodf['tenantId'] = record['tenantAlias']

                    if 'verificationId' in keys:
                        datatodf['verificationId'] = record['verificationId']
                    if 'status' in keys:
                        datatodf['status'] = record['status']
                    if 'externalRefId' in keys:
                        datatodf['customerRef'] = record['externalRefId']
                    
                    if 'createdAt' in keys:
                            datatodf['initial invitation date/time'] = record['createdAt']  
                            #datatodf['Invitation date/time'] = record['createdAt'].astimezone(timezone('Australia/Sydney'))
                            datatodf['Invitation date/time(AEST)'] = record['createdAt'] + timedelta(hours=10)
                            datatodf['Invitation date(AEST)'] = datatodf['Invitation date/time(AEST)'].date()  
                            print(record['createdAt'] )
                    if 'updatedAt' in keys:
                           datatodf['updatedAt'] = record['updatedAt'] 
                           datatodf['updated time(AEST)'] = (record['updatedAt'] + timedelta(hours=10)).time()

                    if 'completedAt' in keys:
                        datatodf['completion date/time'] = record['completedAt']  
                        datatodf['completion date(AEST)'] = (record['completedAt']+ timedelta(hours=10)).date()
                        datatodf['completion time(AEST)'] = (record['completedAt']+ timedelta(hours=10)).time()
                    
                    
                                                        
                    if 'results' in keys and  results is not None :
                        #print(results['processingOutput']['documents'][i].keys())
                        datatodf['verification result'] = record['results']['verificationStatus']
                        for i in range(len(record['results']['processingOutput']['documents'])):
                            auth_keys = record['results']['processingOutput']['documents'][i]['authenticityVerificationResult'].keys()
                            
                            datatodf['primary document type'] = record['results']['processingOutput']['documents'][i]['documentType']
                            
                            datatodf['Doc Display Name'] = record['results']['processingOutput']['documents'][i]['documentDisplayName']
                            datatodf['Doc-Authenticity-Check-status'] = record['results']['processingOutput']['documents'][i]['authenticityVerificationResult']['status']
                            datatodf['Doc-Authenticity-Check-reason'] = record['results']['processingOutput']['documents'][i]['authenticityVerificationResult']['statusReason']
                            if  'score' in auth_keys:
                                datatodf['Doc-Authenticity-Check-score'] = record['results']['processingOutput']['documents'][i]['authenticityVerificationResult']['score']
                            elif 'authenticityScore' in auth_keys:
                                datatodf['Doc-Authenticity-Check-score'] = record['results']['processingOutput']['documents'][i]['authenticityVerificationResult']['authenticityScore']  
                            if record['results']['processingOutput']['documents'][i]['expiryCheckRequired'] == True:
                                datatodf['Expiry-Check-status'] = record['results']['processingOutput']['documents'][i]['expiryCheckResult']['status']
                                datatodf['Expiry-Check-reason'] = record['results']['processingOutput']['documents'][i]['expiryCheckResult']['statusReason']
                            if 'reviewEditCheckResult' in record['results']['processingOutput']['documents'][i].keys():
                                datatodf['Data-Edit-Check-status'] = record['results']['processingOutput']['documents'][i]['reviewEditCheckResult']['status']
                                datatodf['Data-Edit-Check-reason'] = record['results']['processingOutput']['documents'][i]['reviewEditCheckResult']['statusReason']
                            if record['results']['processingOutput']['documents'][i]['faceMatchCheckRequired'] == True:
                                datatodf['Face-Match-Check-status'] = record['results']['processingOutput']['documents'][i]['faceMatchVerificationResult']['status']
                                datatodf['Face-Match-Check-reason'] = record['results']['processingOutput']['documents'][i]['faceMatchVerificationResult']['statusReason']
                                datatodf['Face-Match-Check-score'] = record['results']['processingOutput']['documents'][i]['faceMatchVerificationResult']['detail']['similarity']
                            datatodf['Liveness-status'] = record['results']['processingOutput']['documents'][i]['liveness']['status']
                            datatodf['Liveness-score'] = record['results']['processingOutput']['documents'][i]['liveness']['score']
                            if 'authoritativeVerificationResult' in record['results']['processingOutput']['documents'][i].keys():
                                datatodf['authoritative-Check-status'] = record['results']['processingOutput']['documents'][i]['authoritativeVerificationResult']['status']
                            datatodf['authoritative-Check-reason'] = record['results']['processingOutput']['documents'][i]['authoritativeVerificationResult']['statusReason']
                            datatodf['authoritative-check-detail'] = record['results']['processingOutput']['documents'][i]['authoritativeVerificationResult']['detail']
                            if len(record['results']['processingOutput']['documents']) > 1:
                                datatodf['Secondary Doc Display Name'] = record['results']['processingOutput']['documents'][1]['documentDisplayName']
                    print("*************************************")  
                        
                    finalScores.append(datatodf)
        return finalScores



if __name__ == "__main__":    
    
    #connectionString = "mongodb+srv://revathi:ncFp5BgErH4C7M5q@cluster0-gpn3z.mongodb.net/admin?authSource=admin&replicaSet=Cluster0-shard-0&readPreference=primary&authMechanism=SCRAM-SHA-1&appname=MongoDB%20Compass&ssl=true"
    connectionString = "mongodb+srv://revathi:oa1sktMzBlzLvR0V@truuth-cluster-au.nfws6.mongodb.net/admin?authSource=admin&replicaSet=atlas-2e1zer-shard-0&w=majority&readPreference=primary&authMechanism=SCRAM-SHA-1&appname=MongoDB%20Compass&retryWrites=true&ssl=true"
    Verifications(connectionString)