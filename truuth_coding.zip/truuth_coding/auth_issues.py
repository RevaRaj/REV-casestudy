'''from pymongo import MongoClient
import pandas as pd
from datetime import date, timedelta
import os

from sqlalchemy import null

collectionName = "verifications"
#   Add the tenants here if needed

listOfTenants = ["acdemo1", "admin", "advanceai", "afg", "afg-consumer",
                    "caf","client", "config","console","frostyinc",
                    "fruuth","give", "gym","iag","iip",
                    "jiafinance","laddr","lgf","local","lociiparser",
                    "macquarie","manual-verification","movigo",
                    "newtnt","paytron","petsure","platform",
                    "propper","raineandhome","releaseau","right2drive",
                    "selfonboarding","socar","supporttenant","truuthdemo1",
                    "truuthproduct","truuthsupport","tup","v2testing",
                    "numobile", "afg", "hays"]
list_of_verifications = ['9VwK79juQdxV2K48Lhqd','O9SO2v4981QQDof6dWLl','Z5U1Rm6gFVTiVEU7r3uJ','Z5U1Rm6gFVTiVEU7r3uJ','F8DZuCLW1t9yYJZGDj5j','oP6SKjuBxJ4DzArhqGT5','DmOXcoov0XaOVbtnVyGL','0bC9IkFiqPUFBFL0AAXK','Ez3gYkLQO01ncnjbS079','pUWJ7aOnd9MChKDrjrxW','cYvwao5TNhdUgInnCyko','rJENxmVlFr3afaVHkO8N','x53xlCQSPswpuWg2UFSC','YNv9mLYwzluSaL8rQ5xM','BUdlJFfPmiEmTorKWnvs','27XI0fOAEV5DqPhGvgGx','bNlxjrGc1UH2Ub5FuMy3','tGJ01l96BvjC9eaScl0J','zpeAMamBNjoRxrQt1NGc','lN6bDIVqxP9ZPpAOEbyT','E9rYxS042dAPORMAi2b5','O85wweMvP8COGlq9qkPX','IYaTMK8QChW5QihO0DoN','rguJtrG8NVB3QHBacWIY','FFXkDp4KB9209wbNQumn','uxbGuNQO1NJK7PiOclPn','xGB9F48cqDeVhEF6I4kL','iACxcKEqamfoG0RQOPZM','5imVeYtc4CnwhFF0UPBb','2cm376uR74g6wdPcSFDj','nAAw752fDj1y26GNJDnp']

days_date = date.today()-timedelta(days = 6)
class Verifications:
    def __init__(self,connection):
        self.connectionString = connection
        self.get_database()

    def get_database(self):
        
        # Provide the mongodb atlas url to connect python to mongodb
        CONNECTION_STRING = self.connectionString

        # Create a connection using MongoClient and get all database names
        client = MongoClient(CONNECTION_STRING)
        databases = client.list_database_names()
        directory = self.create_directory(str(date.today()))
        #directory = self.create_directory(str(date.today() - timedelta(days = 1)))

        for db in databases:            
            collections = client[db].list_collection_names()
                       
            if db in listOfTenants and collectionName in collections:
                records = client[db][collectionName]
                print("tenant : ",db)
                scores = self.get_reports(records)
                df = pd.DataFrame(scores)
                if not df.empty:
                    print(df,"\n*****************************************\n")
                    df.to_csv(f"{directory}/auth.csv",mode='a',header=False,index=False)
            

    def create_directory(self,folder):
        current_directory = os.getcwd()
        final_directory = os.path.join(current_directory, folder)
        if not os.path.exists(final_directory):
            os.makedirs(final_directory)

        return final_directory

    def get_reports(self,records):
        finalScores = []

        for record in records.find():
                datatodf = {}
                keys = list(record.keys())                
                results = record.get('results',None)
                
                #if 'createdAt' in keys and record['createdAt'].date() == (date.today() - timedelta(days = 1)) and record['status'] == 'DONE':
                if record['status'] == 'DONE':   
                    print(record['verificationId'])
                    if 'tenantAlias' in keys:
                        datatodf['tenantName'] = record['tenantAlias']

                    if 'createdAt' in keys:
                            datatodf['createdAt'] = record['createdAt']    
                     

                    if 'verificationId' in keys:
                        datatodf['verificationId'] = record['verificationId']
                                       
                    if 'results' in keys and results is not None:
                        #print(record['verificationId'])
                        auth_result = results.get('processingOutput').get('documents')#.get('authenticityVerificationResult')
                        
                        for i in range(len(record['results']['processingOutput']['documents'])):
                            #if  record['verificationId'] in  list_of_verifications and record['verificationId'] not in ['uvn4aJElW0EimWrJg2il']:
                            result1 = auth_result[i].get('authenticityVerificationResult')
                            auth_keys = result1.keys()
                            if  record['verificationId'] not in ['uvn4aJElW0EimWrJg2il'] and 'authenticityScore' in auth_keys:
                                datatodf['authenticityScore'] = record['results']['processingOutput']['documents'][i]['authenticityVerificationResult']['authenticityScore']
                            elif record['verificationId'] not in ['uvn4aJElW0EimWrJg2il'] and 'score' in auth_keys :
                                datatodf['authenticityScore'] = record['results']['processingOutput']['documents'][i]['authenticityVerificationResult']['score']
                            if 'faceMatchVerificationResult' in record['results']['processingOutput']['documents'][i].keys():
                                datatodf['faceMatchScore'] = record['results']['processingOutput']['documents'][i]['faceMatchVerificationResult']['details']['similarity']

                  
                        
                    finalScores.append(datatodf)
        return finalScores





if __name__ == "__main__":    
    
    connectionString = "mongodb+srv://revathi:oa1sktMzBlzLvR0V@truuth-cluster-au.nfws6.mongodb.net/admin?authSource=admin&replicaSet=atlas-2e1zer-shard-0&w=majority&readPreference=primary&authMechanism=SCRAM-SHA-1&appname=MongoDB%20Compass&retryWrites=true&ssl=true"
    Verifications(connectionString)'''


with open("cap.txt","r") as fh:
    c=0
    c=sum(1 for line in fh for ch in line if ch.isupper())
    print(c)