from pymongo import MongoClient
import pandas as pd
from datetime import date

collectionName = "verifications"
listOfTenants = ["numobile", "afg"]


class Verifications:
    def __init__(self):
        self.get_database()

    def get_database(self):
        
        # Provide the mongodb atlas url to connect python to mongodb using pymongo
        CONNECTION_STRING = "mongodb+srv://revathi:oa1sktMzBlzLvR0V@truuth-cluster-au.nfws6.mongodb.net/admin?authSource=admin&replicaSet=atlas-2e1zer-shard-0&w=majority&readPreference=primary&authMechanism=SCRAM-SHA-1&appname=MongoDB%20Compass&retryWrites=true&ssl=true"

        # Create a connection using MongoClient and get all database names
        client = MongoClient(CONNECTION_STRING)
        databases = client.list_database_names()

        for db in databases:            
            collections = client[db].list_collection_names()
                       
            if db in listOfTenants and collectionName in collections:
                records = client[db][collectionName]
                scores = self.get_reports(records)
                df = pd.DataFrame(scores)
                print(df,"\n*****************************************\n")
                df.to_csv(f"{db}{date.today()}.csv",index=False)
          

    def get_reports(self,records):
        finalScores = []
        for record in records.find():
            
                datatodf = {}
                keys = list(record.keys())                
                results = record.get('results',None)
                if 'createdAt' in keys and record['createdAt'].date() >= date.today() and record['status'] == 'DONE':
                    
                    if 'tenantAlias' in keys:
                        datatodf['tenantName'] = record['tenantAlias']

                    if 'createdAt' in keys:
                            datatodf['createdAt'] = record['createdAt']       

                    if 'verificationId' in keys:
                        datatodf['verificationId'] = record['verificationId']
                    
                    if 'results' in keys and results is not None and 'livenessCheck' in keys:
                        processingOutput = results.get('processingOutput',None)
                                               
                        if processingOutput is not None:
                            authVerification = processingOutput.get('documents')[0].get('authenticityVerificationResult',None)
                            faceMatchVerification = processingOutput.get('documents')[0].get('faceMatchVerificationResult',None)

                            if authVerification is not None:
                                datatodf['authenticityScore'] = record['results']['processingOutput']['documents'][0]['authenticityVerificationResult']['authenticityScore']

                            if faceMatchVerification is not None and faceMatchVerification['status']== 'PASSED' :
                                datatodf['faceMatchScore'] = faceMatchVerification['details']['similarity']
                            datatodf['livenessScore'] = record['livenessCheck']['score']
                
                    finalScores.append(datatodf)
        return finalScores





if __name__ == "__main__":    
    
    Verifications()