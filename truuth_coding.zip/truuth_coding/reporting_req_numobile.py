from pymongo import MongoClient
import pandas as pd
from datetime import date, timedelta,datetime
import os

from sqlalchemy import null

collectionName = "verifications"
#   Add the tenants here if needed

listOfTenants = ["numobile"]


class Verifications:
    def __init__(self,connection):
        self.connectionString = connection
        self.get_database()

    def get_database(self):
        
        # Provide the mongodb atlas url to connect python to mongodb
        CONNECTION_STRING = self.connectionString

        # Create a connection using MongoClient and get all database names
        client = MongoClient(CONNECTION_STRING)
        databases = client.list_database_names()
        directory = self.create_directory(str(date.today())+"-prod")
        #directory = self.create_directory(str(date.today() - timedelta(days = 1)))

        for db in databases:            
            
                       
            if db in listOfTenants :
                collections = client[db].list_collection_names()
                for collec in collections:
                    if collectionName == collec:
                        records = client[db][collectionName]
                        print("tenant : ",db)
                        scores = self.get_reports(records)
                        df = pd.DataFrame(scores)
                        if not df.empty:
                            print(df,"\n*****************************************\n")
                            df.to_excel(f"{directory}/{db}-prod-{date.today()}_report.xlsx",index=False)
            

    def create_directory(self,folder):
        current_directory = os.getcwd()
        final_directory = os.path.join(current_directory, folder)
        if not os.path.exists(final_directory):
            os.makedirs(final_directory)

        return final_directory

    def get_reports(self,records):
        finalScores = []

        for record in records.find():
                datatodf = {}
                keys = list(record.keys())                
                results = record.get('results',None)
                documents = record.get('documents',None)
                
                
                if  'createdAt' in keys and record['createdAt'] >= (datetime.today() - timedelta(days = 3)) and record['status'] != 'DELETE':
                    print(record['verificationId'])
                    
                    
                    if 'tenantAlias' in keys:
                        datatodf['tenantId'] = record['tenantAlias']

                    if 'verificationId' in keys:
                        datatodf['verificationId'] = record['verificationId']
                    if 'status' in keys:
                        datatodf['status'] = record['status']
                    if 'externalRefId' in keys:
                        datatodf['customerRef'] = record['externalRefId']
                    
                    if 'createdAt' in keys:
                            datatodf['creation date/time'] = record['createdAt']   
                    if 'updatedAt' in keys:
                           datatodf['updatedAt'] = record['updatedAt'] 
                           
                    if 'completedAt' in keys:
                        datatodf['completion date/time'] = record['completedAt']  
                    
                                                        
                    if 'results' in keys and  results is not None :
                        #print(results['processingOutput']['documents'][0].keys())
                        auth_keys = record['results']['processingOutput']['documents'][0]['authenticityVerificationResult'].keys()
                        datatodf['verification result'] = record['results']['verificationStatus']
                        datatodf['primary document type'] = record['results']['processingOutput']['documents'][0]['documentType']
                        datatodf['Doc Display Name'] = record['results']['processingOutput']['documents'][0]['documentDisplayName']
                        if len(record['results']['processingOutput']['documents']) > 1:
                                datatodf['Secondary Doc Display Name'] = record['results']['processingOutput']['documents'][1]['documentDisplayName']
                        datatodf['Doc-Authenticity-Check-status'] = record['results']['processingOutput']['documents'][0]['authenticityVerificationResult']['status']
                        datatodf['Doc-Authenticity-Check-reason'] = record['results']['processingOutput']['documents'][0]['authenticityVerificationResult']['statusReason']
                        if  'score' in auth_keys:
                            datatodf['Doc-Authenticity-Check-score'] = record['results']['processingOutput']['documents'][0]['authenticityVerificationResult']['score']
                        elif 'authenticityScore' in auth_keys:
                            datatodf['Doc-Authenticity-Check-score'] = record['results']['processingOutput']['documents'][0]['authenticityVerificationResult']['authenticityScore']  
                        if record['results']['processingOutput']['documents'][0]['expiryCheckRequired'] == True:
                            datatodf['Expiry-Check-status'] = record['results']['processingOutput']['documents'][0]['expiryCheckResult']['status']
                            datatodf['Expiry-Check-reason'] = record['results']['processingOutput']['documents'][0]['expiryCheckResult']['statusReason']
                        if 'reviewEditCheckResult' in record['results']['processingOutput']['documents'][0].keys():
                            datatodf['Data-Edit-Check-status'] = record['results']['processingOutput']['documents'][0]['reviewEditCheckResult']['status']
                            datatodf['Data-Edit-Check-reason'] = record['results']['processingOutput']['documents'][0]['reviewEditCheckResult']['statusReason']
                        if record['results']['processingOutput']['documents'][0]['faceMatchCheckRequired'] == True:
                            facematch_keys = record['results']['processingOutput']['documents'][0]['faceMatchVerificationResult'].keys()
                            datatodf['Face-Match-Check-status'] = record['results']['processingOutput']['documents'][0]['faceMatchVerificationResult']['status']
                            datatodf['Face-Match-Check-reason'] = record['results']['processingOutput']['documents'][0]['faceMatchVerificationResult']['statusReason']
                            if 'detail' in facematch_keys:
                                    datatodf['Face-Match-Check-score'] = record['results']['processingOutput']['documents'][0]['faceMatchVerificationResult']['detail']['similarity']
                            elif 'details' in facematch_keys:
                                    datatodf['Face-Match-Check-score'] = record['results']['processingOutput']['documents'][0]['faceMatchVerificationResult']['details']['similarity']
                            
                        datatodf['Liveness-status'] = record['results']['processingOutput']['documents'][0]['liveness']['status']
                        datatodf['Liveness-score'] = record['results']['processingOutput']['documents'][0]['liveness']['score']
                        if 'authoritativeVerificationResult' in record['results']['processingOutput']['documents'][0].keys():
                            datatodf['authoritative-Check-status'] = record['results']['processingOutput']['documents'][0]['authoritativeVerificationResult']['status']
                            datatodf['authoritative-Check-reason'] = record['results']['processingOutput']['documents'][0]['authoritativeVerificationResult']['statusReason']
                            datatodf['authoritative-check-detail'] = record['results']['processingOutput']['documents'][0]['authoritativeVerificationResult']['detail']
                    print("*************************************")   
                        
                    finalScores.append(datatodf)
        return finalScores



if __name__ == "__main__":    
    
    #connectionString = "mongodb+srv://revathi:ncFp5BgErH4C7M5q@cluster0-gpn3z.mongodb.net/admin?authSource=admin&replicaSet=Cluster0-shard-0&readPreference=primary&authMechanism=SCRAM-SHA-1&appname=MongoDB%20Compass&ssl=true"
    connectionString = "mongodb+srv://revathi:oa1sktMzBlzLvR0V@truuth-cluster-au.nfws6.mongodb.net/admin?authSource=admin&replicaSet=atlas-2e1zer-shard-0&w=majority&readPreference=primary&authMechanism=SCRAM-SHA-1&appname=MongoDB%20Compass&retryWrites=true&ssl=true"
    Verifications(connectionString)